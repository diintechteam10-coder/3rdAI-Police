import 'package:dio/dio.dart';
import '../../../../core/constants/api_constants.dart';
import '../../../../core/services/api_services.dart';
import '../models/camera/response/camera_response_model.dart';

class CameraRepository {
  final Dio _dio = ApiService.dio;
  Future<CameraResponse> getCameras({String? city, String? name}) async {
    final Map<String, dynamic> queryParameters = {};
    if (city != null && city.isNotEmpty) queryParameters['city'] = city;
    if (name != null && name.isNotEmpty) queryParameters['name'] = name;

    final response = await _dio.get(
      ApiConstants.getCameras,
      queryParameters: queryParameters,
      options: Options(
        extra: {'skipClientId': true},
      ),
    );

    return CameraResponse.fromJson(response.data);
  }
}