import 'package:flutter_bloc/flutter_bloc.dart';
import '../../repository/get_geo_camera.dart';
import 'camera_event.dart';
import 'camera_state.dart';

class CameraBloc extends Bloc<CameraEvent, CameraState> {
  final CameraRepository repository;

  CameraBloc({required this.repository}) : super(CameraInitial()) {
    on<FetchCameras>(_onFetchCameras);
  }

  Future<void> _onFetchCameras(
    FetchCameras event,
    Emitter<CameraState> emit,
  ) async {
    emit(CameraLoading());
    try {
      final response = await repository.getCameras(city: event.city, name: event.name);
      emit(CameraLoaded(response));
    } catch (e) {
      emit(CameraError(e.toString()));
    }
  }
}
